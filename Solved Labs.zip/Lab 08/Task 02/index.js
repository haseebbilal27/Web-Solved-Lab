function generateInvitations(...guests) {
    const invitationMessages = guests.map(guest => {
        let message = `<div class="invitation">`;
        message += `<h3>Dear ${guest.name},</h3>`;
        message += `<p>You are invited to our party!`;

        if (guest.additionalDetails) {
            message += ` ${guest.additionalDetails}`;
        }

        message += `</p></div>`;
        return message;
    });

    return invitationMessages;
}

const guests = [
    { name: 'Alice', age: 30, rsvpStatus: 'Yes' },
    { name: 'Bob', age: 25, rsvpStatus: 'No', additionalDetails: 'Please bring your favorite board game!' },
    { name: 'Charlie', age: 35, rsvpStatus: 'Yes' }
];
const invitationList = document.getElementById('invitationList');
const invitations = generateInvitations(...guests);
invitationList.innerHTML = invitations.join('');
