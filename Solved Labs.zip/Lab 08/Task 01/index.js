document.addEventListener('DOMContentLoaded', function() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('logoutForm').style.display = 'block';
        document.getElementById('loggedInUser').textContent = loggedInUser;
    } else {
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('logoutForm').style.display = 'none';
    }
});

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    if (username && password) {
        localStorage.setItem('loggedInUser', username);
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('logoutForm').style.display = 'block';
        document.getElementById('loggedInUser').textContent = username;
    } else {
        alert('Please enter both username and password.');
    }
}
function logout() {
    localStorage.removeItem('loggedInUser');
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('logoutForm').style.display = 'none';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}
