// Task 01
function reverseArray(arr) {
    return arr.slice().reverse();
}

console.log(reverseArray([1, 2, 3]));  

// Task 02 
const car = {
    brand: 'Toyota',
    model: 'Camry',
    year: 2022
};

function carInfo(carObj) {
    return `The ${carObj.brand} ${carObj.model} was manufactured in ${carObj.year}.`;
}

console.log(carInfo(car)); 

//Task 03
function applyFunction(arr, func) {
    return arr.map(func);
}
const numbers = [1, 2, 3];
const doubledNumbers = applyFunction(numbers, x => x * 2);
console.log(doubledNumbers); 
